package com.bankmangmentsystem.www;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankMangmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
